package java02_variable;

public class Var02_TypeCasting {
    public static void main(String[] args) {
        
        
        
    }
}
