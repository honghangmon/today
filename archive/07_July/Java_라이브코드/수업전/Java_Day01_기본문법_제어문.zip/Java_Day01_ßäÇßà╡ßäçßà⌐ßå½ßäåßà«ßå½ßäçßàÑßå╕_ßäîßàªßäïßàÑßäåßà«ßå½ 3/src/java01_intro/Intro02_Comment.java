package java01_intro;


public class Intro02_Comment {
    
    public static void main(String[] args) {       
        // 기호가 등장한 순간부터 끝까지 해당 줄을 주석 처리 
        System.out.println("Hello"); // 이후부터 주석
        
        /*
         * 해당 범위를 주석 처리하겠다.
         */
        
        /**
         * Documentation API를 위한 주석처리
         */
    }
}
